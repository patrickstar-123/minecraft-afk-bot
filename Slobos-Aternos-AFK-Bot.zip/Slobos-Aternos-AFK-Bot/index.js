// === Minecraft AFK Bot Ultimate (Final Stable 24/7 - No API) ===
// By Oswald ❤️ — keeps your Aternos server alive forever!

import mineflayer from "mineflayer";
import fs from "fs";
import pkg from "minecraft-server-util";
const { ping } = pkg;

// === CONFIGURATION ===
const config = {
  bot: {
    username: "Patrick", // nama bot
    host: "CrackedSurv.aternos.me", // server IP
    port: 50043, // server port
    version: false // auto detect version
  },
  autoReconnect: {
    enabled: true,
    delay: 10000 // 10 detik sebelum reconnect
  },
  autoAuth: {
    enabled: false, // ubah ke true kalau perlu login/register
    registerCommand: "/register",
    loginCommand: "/login",
    password: "12345"
  },
  antiAfk: {
    enabled: true,
    interval: 60000 // setiap 60 detik lompat
  },
  autoChat: {
    enabled: true,
    messages: [
      "Hey everyone!",
      "Just chilling here 😎",
      "Love this server ❤️"
    ],
    interval: 180000 // setiap 3 menit
  }
};

// === MAIN ===
let bot;
let reconnectCount = 0;

function startBot() {
  console.log(`[🕒 ${new Date().toLocaleTimeString()}] 🚀 Starting bot instance...`);

  bot = mineflayer.createBot({
    host: config.bot.host,
    port: config.bot.port,
    username: config.bot.username,
    version: config.bot.version
  });

  bot.once("spawn", () => {
    console.log(`[✅] Connected as ${bot.username} to ${config.bot.host}:${config.bot.port}`);

    if (config.autoAuth.enabled) {
      setTimeout(() => {
        bot.chat(`${config.autoAuth.registerCommand} ${config.autoAuth.password} ${config.autoAuth.password}`);
        bot.chat(`${config.autoAuth.loginCommand} ${config.autoAuth.password}`);
        console.log(`[🔐] Auto-auth executed`);
      }, 5000);
    }

    if (config.antiAfk.enabled) startAntiAFK();
    if (config.autoChat.enabled) startAutoChat();
  });

  bot.on("end", handleDisconnect);
  bot.on("error", handleError);
}

// === ANTI-AFK ===
function startAntiAFK() {
  console.log(`[🤖] Anti-AFK enabled.`);
  setInterval(() => {
    if (!bot || !bot.entity) return;
    bot.setControlState("jump", true);
    setTimeout(() => bot.setControlState("jump", false), 500);
    bot.chat("/ping"); // simulasi aktivitas biar gak di-kick
  }, config.antiAfk.interval);
}

// === AUTO CHAT ===
function startAutoChat() {
  console.log(`[💬] Auto chat enabled.`);
  setInterval(() => {
    if (!bot) return;
    const msg = config.autoChat.messages[Math.floor(Math.random() * config.autoChat.messages.length)];
    bot.chat(msg);
    console.log(`[💭] Sent: ${msg}`);
  }, config.autoChat.interval);
}

// === DISCONNECT HANDLER ===
function handleDisconnect(reason) {
  console.log(`[🚫] Kicked: ${JSON.stringify(reason)}`);
  if (config.autoReconnect.enabled) {
    reconnectCount++;
    console.log(`[🔁] Reconnecting in ${config.autoReconnect.delay / 1000}s (Attempt #${reconnectCount})...`);
    setTimeout(startBot, config.autoReconnect.delay);
  }
}

// === ERROR HANDLER ===
function handleError(err) {
  console.error(`[❌] Error: ${err}`);
  if (config.autoReconnect.enabled) {
    reconnectCount++;
    console.log(`[🔁] Reconnecting after error in ${config.autoReconnect.delay / 1000}s.`);
    setTimeout(startBot, config.autoReconnect.delay);
  }
}

// === AUTO MEMORY CLEANUP (TIAP 2 JAM) ===
setInterval(() => {
  if (global.gc) global.gc();
  console.log(`[🧹] RAM cleaned up (${new Date().toLocaleTimeString()})`);
}, 2 * 60 * 60 * 1000);

// === SERVER PING MONITOR (TIAP 5 MENIT) ===
setInterval(async () => {
  try {
    const res = await ping(config.bot.host, config.bot.port);
    console.log(`[🟢 Server alive] ${res.players.online}/${res.players.max} players`);
  } catch {
    console.log(`[🔴 Server unreachable or offline]`);
  }
}, 5 * 60 * 1000);

// === START ===
startBot();
